package Client;

import java.io.*;
import java.net.*;

import Common.MyLogger;
import Common.Packet;
import Common.PacketType;
import Common.Settings;

public class Receiver {
	// Create a logger for this class.
	private MyLogger logger = new MyLogger("Client.Receiver");

	public void getFile(String fn) {
		Packet packet;
		packet = new Packet(PacketType.REQ, 0, fn.length(), fn.getBytes());
		System.out.println(fn.length());

		try {
			// call receiveFile and pass to it the packet just created
			receiveFile(packet);
		} catch (Exception e) {
			// Catch any errors generated and print out a stack trace
			e.printStackTrace();
		}
		
	}
	
	private void sendAck(int sequenceNumber, InetAddress IPAddress, DatagramSocket clientSocket) throws IOException {
		
		Packet packet = new Packet(PacketType.ACK, sequenceNumber, 0, null);
		DatagramPacket sendPacket = new DatagramPacket(packet.getBytes(), packet.getBytes().length, IPAddress, Settings.PORT);
        clientSocket.send(sendPacket);
        logger.sent(packet.getBytes());
	}
	
	/*
	 * This method will receive the packets from the server and process them.
	 */
	private void receiveFile(Packet packet) throws Exception {
		
		byte[]packsize = packet.getBytes();

		
		byte[] receivePac = new byte[1000];
		
	
		DatagramSocket clientSocket = new DatagramSocket();
		DatagramPacket receivePacket = new DatagramPacket(receivePac, receivePac.length);

		String store = "";
		

		int packetsReceived = 0;   
		int nextSeqno = 0;         
		int lastSeqno = 0;         
		int totalData = 0;         

		clientSocket.setSoTimeout(ONE_SECOND_IN_MS);

		InetAddress IPAddress = InetAddress.getByName("127.0.0.1"); 
		

		DatagramPacket sendPacket = new DatagramPacket(packsize, packet.getBytes().length , IPAddress, Settings.PORT);
		
		
		// Send it using the clientSocket
		//...
		System.out.println("Before DAT Trasnmission:");
		clientSocket.send(sendPacket);
		
		
		System.out.println("\nAfter DAT Transmission:");
		// log the data
		logger.sent(packsize);

		// Using a boolean to signal that we have the end of transmission (EOT).  While we don't have the
		// complete file, keep looping
		boolean haveEOT = false;
		while (!haveEOT) {
			try {
				
				Packet receiveData;
				clientSocket.receive(receivePacket);
				logger.received(receivePac);
				Packet receiveData2 = new Packet(receivePac);
				receiveData = receiveData2;
			
				 if (receiveData.getType() == PacketType.ERR) {
					logger.info("Error: ");
					return;
				}

				
				 if (receiveData.getSeqNo() == nextSeqno) 
				 {
					 byte[] tempArray = receiveData.getData();
					 String testString = new String(tempArray);
					 testString = testString.trim();
					 store = store.concat(testString);
					 totalData = totalData + receiveData.getSize(); 
				
				
					if(receiveData.getType() == PacketType.EOT)
					{
						haveEOT = true;
					}
				
					// Track the last sequence number
					// ...
					lastSeqno = nextSeqno; 
				
					// Send an ACK that this sequence was received
					// hint: sendAck(..., ..., clientSocket);
					 sendAck(nextSeqno, IPAddress, clientSocket);
				
					// Set the next expected sequence number.  Remember that we have a window size that
				    // will wrap back to 0 at some point.  The current window size is in the Settings
					// class.  Use it from there !!!  Do not hardcode it!,
					// hint: set nextSeqno
					if(nextSeqno == Settings.WINDOW_SIZE - 1){ 
						nextSeqno = 0; 
					} 

					else 
					{
						nextSeqno++;
					}
				
					// Track the total number of packets received
					// hint: increment packetsReceived
				    packetsReceived++;
				
				// If we got a packet, but not what we're expecting
				} 

				else if (packetsReceived == 0) 
				{
					// do nothing
					
				// Otherwise, we still got a packet, but the sequence number is wrong, log about it and
				// send an ack for the last packet.  The server should figure out what to do from here
				} 

				else 

				{
					logger.info("Received a packet, but not the one we're expecting.");
					
					// Send the ack
					// hint: sendAck(lastSeqno, ...);
					sendAck(lastSeqno, IPAddress, clientSocket);
				}
			} catch (SocketTimeoutException e) {
				logger.info("Receive timeout");
			}
		}
	
		// close the clientSocket and print the file that was received!  Done!  Yippee!!!
		// hint: close the clientSocket
		clientSocket.close();
		
		logger.info("Received the file containing: " + totalData + "(bytes) of data");
		// Print out the file
		System.out.println("HERE: " + store);
	}

	private static int ONE_SECOND_IN_MS = 1000;
	private static String LOCALHOST = "localhost";
}
