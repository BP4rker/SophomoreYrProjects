
This zip file contains 3 directories, a Client, Server, and Common files.  
Building the Server and Client you can then execute them.  A log file will be 
created in the home directory for both the client and server.  


 