package Server;

import java.io.IOException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.logging.Logger;

import Common.MyLogger;
import Common.Packet;
import Common.PacketType;
import Common.Settings;
import Server.UDP;
import Server.PacketManager;

public class Main {
	public static void main(String[] args) {
		// Create a new logger
		MyLogger logger = new MyLogger("Server.main");
		
		// Log that we're starting
		logger.info("Starting");
		
		// Create a Packet to be used when we receive data from the client
		Packet receivedPacket;
		
		// Create some settings that can be used when the server is started.  If it has a "1",
		// then skip the first packet intentionally introducing some errors.  If it is a "2" then
		// skip all packets.
		if (args.length > 0) {
			if (args[0].equals("1"))
				Settings.SKIP_FIRST_PACKET = true;
			else if (args[0].equals("2"))
				Settings.SKIP_ALL_PACKETS = true;
		}
		
		// Dump some setting information
		logger.info("Skipping First Packet in Window: " + Settings.SKIP_FIRST_PACKET);
		logger.info("Skipping All Packets in Window:  " + Settings.SKIP_ALL_PACKETS);
		
		// We need a way to loop getting data and when we're done know to stop.  So create
		// a boolean for that purpose
		// hint: boolean ...
		boolean indication = true;
		try {
			// Create a variable to hold the file sender object but initialize it to null
			Sender sender = null;
			
			while (indication) {
				UDP udpSocket = new UDP();
			
				udpSocket.createService();
			
				try {
					byte[] buff = udpSocket.getPacket(0);
					Packet packetBuffer = new Packet(buff);
					receivedPacket = packetBuffer;

					// If the received packet's type is not a request (REQ), then generate an error
					// if (...) {
					if (receivedPacket.getType() != PacketType.REQ) {
						(new PacketManager(udpSocket)).send(PacketType.ERR,
								"Received " + PacketType.toString(receivedPacket.getType()) + 
								", not sure what that command does at this stage.");
						continue;
					}
				} catch (SocketTimeoutException e) {
					continue;
				}
				
				
				sender = new Sender(udpSocket);

				try {
					
					byte[] receiveArr = receivedPacket.getData();
					String confirm = new String(receiveArr);
			
					System.out.println(confirm);
					sender.sendFile(confirm);
					udpSocket.close();
					indication = false;
				} catch (IOException e) {
					
					PacketManager pm = new PacketManager(udpSocket);
					pm.send(PacketType.ERR, "No such file or permission denied.");
					pm.processAck();
					udpSocket.close();
				}
				
			}
		// Process/catch/print other errors
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WrongPacketTypeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
