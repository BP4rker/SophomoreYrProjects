package Server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;

import Common.MyLogger;
import Common.Settings;

public class UDP {
	private MyLogger logger = new MyLogger("Server.UDP");

	public void createService() throws SocketException {
		logger.info(restarted ? "Res" : "S" + "starting Server on Port: " + Settings.PORT);
		
		restarted = true;
	    serverSocket = new DatagramSocket(Settings.PORT);
	}

	public byte[] getPacket(int timeout) throws SocketTimeoutException {
		byte[] receiveData = new byte[1024];
		DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
		try {
			serverSocket.setSoTimeout(timeout);
			
			serverSocket.receive(receivePacket);
			
			logger.received(receiveData);
			
			System.out.println("Got packet! (check)");
			
			System.out.println(clientPort);
			if (clientPort == 0) {
			
				clientAddress = receivePacket.getAddress();
				clientPort = receivePacket.getPort();
				
				System.out.println("Client's Address: " + clientAddress);
				System.out.println("Client's Port Number: " + clientPort);
				

				logger.info("Established connection with: " + clientAddress + ", Port:" + clientPort);
			}
		} catch (SocketTimeoutException e) {
			throw e;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Unable to get data from socket.", e);
		}
		// get the client message
		return receiveData;
	}

	public void sendPacket(int size, byte[] sendData) {

		System.out.println("Sending the Packet. (checking for:");
		totalData += size;
		totalDataWithHdr += size + 12;

		DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
		try {
			logger.sent(sendData);
			
			System.out.println("Client's Port Number: " + clientPort);
			serverSocket.send(sendPacket);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Unable to send reply", e);
		}
	}

	public void reset() {
		
		restarted = true;
		clientPort = 0;

	}
	
	public void close() {
		
		serverSocket.close();
	}
	
	public void stats() {
		logger.info(String.format("    Data:                              %4d", totalData));
		logger.info(String.format("    Data Including the Packet Headers: %4d", totalDataWithHdr));		
	}
	private DatagramSocket serverSocket;
	private int clientPort = 0;
	private InetAddress clientAddress;
	
	private static boolean restarted = false;
	private static int totalData = 0;
	private static int totalDataWithHdr = 0;
}
