export class Client {
  _id: string;
  name: string;
  password: string;
  email: string;
  age: Number;
  height: Number;
  weight: Number;
  sport: string;
  role: string;
  location: string;
  bio: string;
}
