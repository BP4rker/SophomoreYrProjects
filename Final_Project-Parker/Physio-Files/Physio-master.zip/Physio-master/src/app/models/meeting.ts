export class Meeting {
  _id: string;
  name: string;
  date: string;
  location: string;
  goals: string;
  clientEmail: string;
  trainerEmail: string;
}
