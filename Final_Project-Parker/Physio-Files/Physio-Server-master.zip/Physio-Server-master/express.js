var express = require('express');
var app = express();
app.express = express;
module.exports = app;
